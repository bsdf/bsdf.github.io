# This file is part of WebKollage.

# WebKollage is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# WebKollage is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with WebKollage.  If not, see <https://www.gnu.org/licenses/>.

import log
import random
import util

from binascii import crc32

banned_images = set(
    [
        # lj-18.png
        1293104510,
        # imgur-removed.png
        652992840,
        # youtube-placeholder.jpg
        2501179627,
    ]
)


class OpacityFilter:
    def __init__(self, lower=50, upper=255):
        self.lower = lower
        self.upper = upper

    def process(self, img):
        img.putalpha(random.randrange(self.lower, self.upper))
        return img


class ResizeFilter:
    def __init__(self, maxw=1440, maxh=810):
        self.maxw = maxw
        self.maxh = maxh

    def process(self, img):
        w, h = img.size
        if (w > self.maxw or h > self.maxh) and self.should_resize():
            log.debug("resizing image: w: %s h: %s" % (w, h))
            img.thumbnail((self.maxw, self.maxh))

        return img

    def should_resize(self):
        n = random.choice(range(50, 100))
        if n == 69:
            log.debug("DING DING DING not resizing giant image")
            return False
        return True


class ImageManager:
    def __init__(self, filters=[ResizeFilter(), OpacityFilter()]):
        self.filters = filters

    def load_image(self, url):
        try:
            img = util.image_from_url(url)
            if self.is_banned_image(img):
                log.debug("skipping banned image")
                return None
            return self.process_image(img)

        except Exception as e:
            log.warn("caught exception in ImageManager.load_image: %s" % e)
            return None

    def is_banned_image(self, img):
        checksum = crc32(img.tobytes())
        return checksum in banned_images

    def process_image(self, img):
        for filter in self.filters:
            img = filter.process(img)
        return img
