# This file is part of WebKollage.

# WebKollage is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# WebKollage is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with WebKollage.  If not, see <https://www.gnu.org/licenses/>.

# TODO:
# * twitter recently posted
# * reddit sources

import log
import random
import util
import re
import json

from util import addon
from image import ImageManager
from collections import deque
from binascii import crc32


class ScraperManager:
    def __init__(self, scrapers, buffer_size=50):
        random.shuffle(scrapers)
        self.scrapers = scrapers
        self.buffer_size = buffer_size
        self.urls = set()
        self.seen = deque([], 10000)
        self.image_manager = ImageManager()

    def get_next_image(self):
        img = None
        while img is None:
            try:
                url = self.get_next_url()
                url_hash = crc32(url.encode("utf-8"))
                if url_hash in self.seen:
                    log.debug("skipping already seen url: %s" % url)
                    continue
                else:
                    self.seen.append(url_hash)

                log.debug("loading image: %s" % url)
                img = self.image_manager.load_image(url)

            except Exception as e:
                log.debug("caught exception calling image_manager: %s" % e)

        return img

    def get_next_url(self):
        if self.should_gather():
            self.gather_urls()

        [url] = random.sample(self.urls, 1)
        self.urls.remove(url)
        return url

    def should_gather(self):
        log.debug("len(urls) = %s" % len(self.urls))
        return (not addon.abort_requested) and len(self.urls) < self.buffer_size

    def gather_urls(self):
        while self.should_gather():
            log.debug("gathering urls...")
            for scraper in self.scrapers:
                if addon.abort_requested:
                    log.debug("abort requested, stopping gather_urls()")
                    break

                try:
                    self.urls |= set(scraper.get())
                except Exception as e:
                    log.debug("caught exception: %s" % e)


class WikimediaRandomPage:
    def __init__(self):
        pass

    def get(self):
        log.debug("grabbing images from wikipedia")
        return [self.get_one() for _ in range(5)]

    def get_one(self):
        soup = util.soup_from_url(
            "https://commons.wikimedia.org/wiki/Special:Random/File"
        )
        tags = soup.select("#file a img")
        if tags is None or len(tags) == 0:
            return []

        url = tags[0]["src"]
        return url


class LivejournalLatestImages:
    def get(self):
        log.debug("grabbing images from livejournal")
        soup = util.soup_from_url("https://www.livejournal.com/stats/latest-img.bml")
        images = soup.find_all("recent-image")
        if images is None or len(images) == 0:
            return []

        return [image["img"] for image in util.shuffle_and_pick(images, 20)]


class ImgurLatest:
    def get(self):
        log.debug("grabbing images from imgur")
        json = util.json_from_url(
            "https://api.imgur.com/post/v1/posts?client_id=546c25a59c58ad7&filter[section]=eq:new&page=1&sort=-time"  # noqa: E501
        )

        if json is None or len(json) == 0:
            return []

        ids = [item["cover_id"] for item in util.shuffle_and_pick(json, 20)]
        return list(map(lambda id: "https://i.imgur.com/%s.jpg" % id, ids))


class BingImage:
    def __init__(self, dict=util.DictionaryService(), nsfw=True):
        self.dict = dict
        self.nsfw = nsfw

    def get(self):
        word = self.dict.get_random_word()
        log.debug("grabbing images from bing with query: %s" % word)

        url = "https://www.bing.com/images/search?q=%s" % word
        if self.nsfw:
            url += "&adlt=off"

        soup = util.soup_from_url(url)
        results = soup.find_all("a", "iusc")

        urls = [ m["murl"] for m in [ json.loads(result["m"]) for result in results ]]
        return util.shuffle_and_pick(urls, 100)

        # results = soup.find_all("a", "thumb")
        # return [result["href"] for result in util.shuffle_and_pick(results, 100)]


class FlickrSearch:
    bad_users = re.compile("|".join(["16445093@N03", "allseeingaerosol"]))

    def not_bad_user(tag):
        return tag.name == "item" and not tag.find_all(
            "author",
            attrs={
                "flickr:profile": lambda x: not re.search(
                    FlickrSearch.bad_users, tag, x
                )
            },
        )

    def __init__(self, dict=util.DictionaryService()):
        self.dict = dict

    def get(self):
        tags = ",".join(self.dict.get_random_word(False).split(" "))
        log.debug("grabbing images from flickr with tags: %s" % tags)

        url = (
            "https://www.flickr.com/services/feeds/photos_public.gne?format=rss_200_enc&tags=%s"  # noqa: E501
            % tags
        )

        soup = util.soup_from_url(url)
        items = soup.find_all(FlickrSearch.not_bad_user)
        filtered = [item.enclosure["url"] for item in items]

        return util.shuffle_and_pick(filtered, 10)


class Twitter:
    regex = re.compile("media%2F(.*)\.(.*)%3F")

    def __init__(self, dict=util.DictionaryService()):
        self.dict = dict

    def get(self):
        word = self.dict.get_random_word()
        log.debug("grabbing images from nitter with query: %s" % word)

        url = "https://nitter.net/search?f=tweets&q=%s&f-images=on" % word
        soup = util.soup_from_url(url, False)
        results = soup.select(".still-image img")
        log.debug("got %i images from nitter" % len(results))
        return [
            get_url(result["src"]) for result in util.shuffle_and_pick(results, 100)
        ]

    def get_url(self, url):
        match = re.search(self.regex, url)
        if match:
            return "https://pbs.twimg.com/media/%s?format=%s&name=orig" % (
                match.group(1),
                match.group(2),
            )
