# This file is part of WebKollage.

# WebKollage is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# WebKollage is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with WebKollage.  If not, see <https://www.gnu.org/licenses/>.

# TODO
# * icon.png, fanart.png https://kodi.wiki/view/Add-on_structure#icon.png

# configuration
# * turn sources on/off
# * wordlist on/off, specify
# * frequency of new image
# * opacity of images
# * frequency of new collage
# * image placement algorithm (random, grid, etc)

import xbmcgui
import xbmc
import xbmcvfs
import log
import sys
import time
import util

from util import addon, settings
from kollage import Kollage
from scrapers import (
    ScraperManager,
    WikimediaRandomPage,
    LivejournalLatestImages,
    ImgurLatest,
    BingImage,
    FlickrSearch,
)


class WebKollage(xbmcgui.WindowXMLDialog):
    class ExitMonitor(xbmc.Monitor):
        def __init__(self, exit_callback):
            self.exit_callback = exit_callback

        def onScreensaverDeactivated(self):
            log.info("received onScreensaverDeactivated event")
            self.exit_callback()

        def onDPMSActivated(self):
            log.info("received onDPMSActivated event")
            self.exit_callback()

    def onInit(self):
        log.debug("inside onInit")
        self.kollage = None
        self.kollage_started = None

        self.monitor = self.ExitMonitor(self.exit)
        self.img_ctrl = self.getControl(1)

        self.img_delay = settings.img_delay
        self.blank_delay = settings.blank_delay
        self.refresh_delay = settings.refresh_delay

        self.setup_scrapers()
        self.time_started = time.time()
        self.draw()

    def setup_scrapers(self):
        rand_dict = util.DictionaryService()
        scrapers = [
            ImgurLatest(),
            LivejournalLatestImages(),
            WikimediaRandomPage(),
            BingImage(rand_dict, settings.nsfw),
        ]

        dict_file = "%s%s" % (addon.data_path, settings.dict_file)
        if xbmcvfs.exists(dict_file):
            word_dict = util.DictionaryService(dict_file)
            scrapers += [
                BingImage(word_dict, settings.nsfw),
                # FlickrSearch(word_dict)
                ]

        self.scrapers = ScraperManager(scrapers)

    def draw(self):
        while not addon.abort_requested:
            if self.should_blank():
                log.debug("blank_delay passed, blanking screen")
                self.blank()
                break

            if self.kollage is None or self.should_refresh():
                log.debug(
                    "refresh delay passed. start: %s delay: %s"
                    % (self.kollage_started, self.refresh_delay)
                )
                self.create_new_kollage()

            self.kollage.paste(self.get_next_image())
            self.img_ctrl.setImage(self.kollage.save(), False)

            if self.monitor.waitForAbort(self.img_delay):
                log.debug("monitor.waitForAbort returned nonzero")
                addon.abort_requested = True

    def create_new_kollage(self):
        if self.kollage is not None:
            log.debug("cleaning up old kollage")
            self.kollage.cleanup()

        log.debug("creating new kollage")
        self.kollage = Kollage(addon.data_path)
        self.kollage_started = time.time()

    def get_next_image(self):
        return self.scrapers.get_next_image()

    def should_refresh(self):
        return util.time_passed(self.kollage_started, self.refresh_delay)

    def should_blank(self):
        return util.time_passed(self.time_started, self.blank_delay)

    def blank(self):
        self.img_ctrl.setImage("%s/black.png" % addon.media_path)

    def exit(self):
        log.debug("inside exit(), setting abort_requested")
        addon.abort_requested = True
        self.monitor = None
        self.kollage.cleanup()
        self.close()


if __name__ == "__main__":
    screensaver = WebKollage("webkollage.xml", addon.path, "default")
    screensaver.doModal()

    del screensaver
    sys.modules.clear()
