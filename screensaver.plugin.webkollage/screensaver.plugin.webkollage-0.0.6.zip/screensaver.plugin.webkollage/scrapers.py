# This file is part of WebKollage.

# WebKollage is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# WebKollage is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with WebKollage.  If not, see <https://www.gnu.org/licenses/>.

# TODO:
# * google image search
# * bing image search
# * other random images
# * twitter recently posted
# * flickr recently posted: http://www.flickr.com/explore/
# * flickr rss?
# * random wikipedia page: http://en.wikipedia.org/wiki/Special:Random
# * imgur: http://imgur.com/search?qs=thumb&q_any=
# * redgifs thumbnail?
# * reddit sources

import log
import random
import util

from image import ImageManager
from collections import deque
from binascii import crc32


class ScraperManager:
    def __init__(self, scrapers, buffer_size=50):
        self.scrapers = scrapers
        self.buffer_size = buffer_size
        self.urls = set()
        self.seen = deque([], 10000)
        self.image_manager = ImageManager()

    def get_next_image(self):
        img = None
        while img is None:
            try:
                url = self.get_next_url()
                url_hash = crc32(url)
                if url_hash in self.seen:
                    log.debug("skipping already seen url: %s" % url)
                    continue
                else:
                    self.seen.append(url_hash)

                img = self.image_manager.load_image(url)

            except Exception as e:
                log.debug("caught exception calling image_manager: %s" % e)

        return img

    def get_next_url(self):
        if self.should_gather():
            self.gather_urls()

        [url] = random.sample(self.urls, 1)
        self.urls.remove(url)

        # random.shuffle(self.urls)
        # return self.urls.pop()
        return url

    def should_gather(self):
        log.debug("len(urls) = %s" % len(self.urls))
        return len(self.urls) < self.buffer_size

    def gather_urls(self):
        while self.should_gather():
            log.debug("gathering urls...")
            for scraper in self.scrapers:
                try:
                    # self.urls += scraper.get()
                    self.urls |= set(scraper.get())
                except Exception as e:
                    log.debug("caught exception: %s" % e)


class WikimediaRandomPage:
    def __init__(self):
        pass

    def get(self):
        log.debug("grabbing images from wikipedia")
        return [self.get_one() for _ in range(5)]

    def get_one(self):
        soup = util.soup_from_url(
            "https://commons.wikimedia.org/wiki/Special:Random/File"
        )
        tags = soup.select("#file a img")
        if tags is None or len(tags) == 0:
            return []

        url = tags[0]["src"]
        return url


class LivejournalLatestImages:
    def get(self):
        log.debug("grabbing images from livejournal")
        soup = util.soup_from_url("https://www.livejournal.com/stats/latest-img.bml")
        images = soup.find_all("recent-image")
        if images is None or len(images) == 0:
            return []

        return [image["img"] for image in util.shuffle_and_pick(images, 20)]


class ImgurLatest:
    def get(self):
        log.debug("grabbing images from imgur")
        json = util.json_from_url(
            "https://api.imgur.com/post/v1/posts?client_id=546c25a59c58ad7&filter[section]=eq:new&page=1&sort=-time"
        )

        if json is None or len(json) == 0:
            return []

        ids = [item["cover_id"] for item in util.shuffle_and_pick(json, 20)]
        return list(map(lambda id: "https://i.imgur.com/%s.jpg" % id, ids))


class BingImage:
    def __init__(self, dict=util.DictionaryService(), nsfw=True):
        self.dict = dict
        self.nsfw = nsfw

    def get(self):
        word = self.dict.get_random_word()
        log.debug("grabbing images from bing with query: %s" % word)

        url = "https://www.bing.com/images/search?q=%s" % word
        if self.nsfw:
            url += "&adlt=off"

        soup = util.soup_from_url(url)
        results = soup.find_all("a", "thumb")
        return [result["href"] for result in util.shuffle_and_pick(results, 100)]


class FlickrSearch:
    def __init__(self, dict=util.DictionaryService()):
        self.dict = dict

    def get(self):
        tags = ",".join(self.dict.get_random_word(False).split(" "))
        log.debug("grabbing images from flickr with tags: %s" % tags)

        url = (
            "https://www.flickr.com/services/feeds/photos_public.gne?format=rss_200_enc&tags=%s"
            % tags
        )

        soup = util.soup_from_url(url)
        images = soup.find_all("enclosure")
        return [img["url"] for img in util.shuffle_and_pick(images, 10)]
