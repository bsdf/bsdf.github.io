# This file is part of WebKollage.

# WebKollage is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# WebKollage is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with WebKollage.  If not, see <https://www.gnu.org/licenses/>.

import os
import random
import time
import log

from PIL import Image


class Kollage:
    def __init__(self, path, size=(1920, 1080)):
        self.path = path
        self.filename = None
        self.size = size
        self.bg = Image.new("RGBA", size, color=(0, 0, 0))
        random.seed()

    def paste(self, img):
        self.process_image(img)

        tmp = Image.new("RGBA", self.size)
        tmp.paste(img, self.get_position(img))

        self.bg.alpha_composite(tmp)

    def get_new_filename(self):
        return "%s/%s.png" % (self.path, int(time.time()))

    def get_position(self, img):
        bgw, bgh = self.size
        imgw, imgh = img.size
        halfw, halfh = (int(imgw / 2), int(imgh / 2))

        return (
            random.randrange(halfw * -1, bgw - halfw),
            random.randrange(halfh * -1, bgh - halfh),
        )

    def process_image(self, img):
        img.putalpha(random.randrange(50, 255))

    def save(self):
        filename = self.get_new_filename()
        self.bg.save(filename, "PNG")

        if self.filename is not None:
            os.remove(self.filename)

        self.filename = filename
        return self.filename

    def cleanup(self):
        if self.filename is not None and os.path.isfile(self.filename):
            log.debug("cleaning up kollage file: %s" % self.filename)
            os.remove(self.filename)
