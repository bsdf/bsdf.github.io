# This file is part of WebKollage.

# WebKollage is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# WebKollage is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with WebKollage.  If not, see <https://www.gnu.org/licenses/>.

# TODO
# * use xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
#   for temp dir
# * use xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path')).decode('utf-8')
#   for access to blank.png
# * icon.png, fanart.png https://kodi.wiki/view/Add-on_structure#icon.png

# configuration
# * turn sources on/off
# * wordlist on/off, specify
# * frequency of new image
# * opacity of images
# * frequency of new collage
# * image placement algorithm (random, grid, etc)


import xbmcaddon
import xbmcgui
import xbmc
import log
import sys
import time
import util

from kollage import Kollage
from scrapers import (
    ScraperManager,
    WikimediaRandomPage,
    LivejournalLatestImages,
    ImgurLatest,
    BingImage,
    FlickrSearch,
)

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo("name")
addon_path = addon.getAddonInfo("path")

word_dict = util.DictionaryService("%s/resources/dict/en" % addon_path)
rand_dict = util.DictionaryService()


class WebKollage(xbmcgui.WindowXMLDialog):
    class ExitMonitor(xbmc.Monitor):
        def __init__(self, exit_callback):
            self.exit_callback = exit_callback

        def onScreensaverDeactivated(self):
            log.info("received onScreensaverDeactivated event")
            self.exit_callback()

        def onDPMSActivated(self):
            log.info("received onDPMSActivated event")
            self.exit_callback()

    def onInit(self):
        log.debug("inside onInit")
        self.kollage = None
        self.kollage_started = None

        self.abort_requested = False
        self.monitor = self.ExitMonitor(self.exit)
        self.img_ctrl = self.getControl(1)

        # self.img_delay = addon.getSettingInt("image_delay")
        self.img_delay = 10
        # self.blank_delay = addon.getSettingInt("blank_delay")
        self.blank_delay = 60 * 40
        # self.blank_delay = addon.getSettingInt("refresh_delay")
        self.refresh_delay = 60 * 10

        self.scrapers = ScraperManager(
            [
                BingImage(word_dict),
                ImgurLatest(),
                FlickrSearch(word_dict),
                LivejournalLatestImages(),
                WikimediaRandomPage(),
                BingImage(rand_dict),
                FlickrSearch(rand_dict),
            ]
        )

        self.time_started = time.time()
        self.draw()

    def draw(self):
        while not self.abort_requested:
            if self.should_blank():
                log.debug("blank_delay passed, blanking screen")
                self.blank()
                break

            if self.kollage is None or self.should_refresh():
                log.debug(
                    "refresh delay passed. start: %s delay: %s"
                    % (self.kollage_started, self.refresh_delay)
                )
                self.create_new_kollage()

            self.kollage.paste(self.get_next_image())
            self.img_ctrl.setImage(self.kollage.save(), False)

            if self.monitor.waitForAbort(self.img_delay):
                log.debug("monitor.waitForAbort returned nonzero")
                self.abort_requested = True

    def create_new_kollage(self):
        if self.kollage is not None:
            log.debug("cleaning up old kollage")
            self.kollage.cleanup()

        log.debug("creating new kollage")
        self.kollage = Kollage(addon_path)
        self.kollage_started = time.time()

    def get_next_image(self):
        return self.scrapers.get_next_image()

    def should_refresh(self):
        return util.time_passed(self.kollage_started, self.refresh_delay)

    def should_blank(self):
        return util.time_passed(self.time_started, self.blank_delay)

    def blank(self):
        self.img_ctrl.setImage(
            "%s/resources/skins/default/media/black.png" % addon_path
        )

    def exit(self):
        log.debug("inside exit(), setting abort_requested")
        self.abort_requested = True
        self.monitor = None
        self.kollage.cleanup()
        self.close()


if __name__ == "__main__":
    screensaver = WebKollage("webkollage.xml", addon_path, "default")
    screensaver.doModal()

    del screensaver
    sys.modules.clear()
