# This file is part of WebKollage.

# WebKollage is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# WebKollage is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with WebKollage.  If not, see <https://www.gnu.org/licenses/>.

import xbmc


def _log(txt, level):
    xbmc.log("[webkollage] %s" % txt, level)


def debug(txt):
    _log(txt, level=xbmc.LOGDEBUG)


def info(txt):
    _log(txt, level=xbmc.LOGINFO)


def notice(txt):
    _log(txt, level=xbmc.LOGNOTICE)


def warn(txt):
    _log(txt, level=xbmc.LOGWARNING)


def error(txt):
    _log(txt, level=xbmc.LOGERROR)
