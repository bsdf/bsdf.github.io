# This file is part of WebKollage.

# WebKollage is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# WebKollage is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with WebKollage.  If not, see <https://www.gnu.org/licenses/>.

import requests
import log
import time
import random
import xbmc
import xbmcaddon
import xbmcvfs

from PIL import Image
from io import BytesIO
from bs4 import BeautifulSoup

try:
    from urllib.parse import quote_plus
except ImportError:
    log.debug("urllib.parse not found. in python2")
    from urllib import quote_plus


class Addon:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.name = self._get_info("name")
        self.path = self._get_info("path")
        self.media_path = "%s/resources/skins/default/media" % self.path

        self.data_path = self._get_info("profile")
        if not xbmcvfs.exists(self.data_path):
            log.debug("data path [%s] doesn't exist. creating" % self.data_path)
            xbmcvfs.mkdir(self.data_path)

        self.abort_requested = False

    def _get_info(self, k):
        return xbmc.translatePath(self.addon.getAddonInfo(k))  # .decode("utf-8")


addon = Addon()


class Settings:
    def __init__(self):
        # self.img_delay = self.addon.getSettingInt("image_delay")
        self.img_delay = 10
        # self.blank_delay = self.addon.getSettingInt("blank_delay")
        self.blank_delay = 60 * 40
        # self.refresh_delay = self.addon.getSettingInt("refresh_delay")
        self.refresh_delay = 60 * 10
        # self.nsfw = self.addon.getSettingBool("nsfw")
        self.nsfw = True
        # self.nsfw = self.addon.getSettingPath("dict_file")
        self.dict_file = "dict"


settings = Settings()


class DictionaryService:
    def __init__(self, dict_file=None):
        if dict_file is not None:
            try:
                with open(dict_file) as f:
                    lines = f.readlines()
                    self.words = [x.strip() for x in lines]
                    log.debug("loaded %s words from %s" % (len(self.words), dict_file))
            except Exception as e:
                log.debug("error opening dict file %s: %s" % (dict_file, e))
                self.words = []
        else:
            self.words = []

    def get_random_word(self, encode=True):
        if len(self.words) > 0:
            word = random.choice(self.words)
            if encode:
                return quote_plus(word)
            return word
        else:
            # just return a random number
            return "%s" % random.randrange(0, 99999999)


def image_from_url(url):
    response = requests.get(url, timeout=5)
    return Image.open(BytesIO(response.content))


def soup_from_url(url, verify=True):
    page = requests.get(url, verify=verify)
    return BeautifulSoup(page.text, "html.parser")


def json_from_url(url):
    response = requests.get(url)
    return response.json()


def time_passed(start, delay):
    return time.time() - start >= delay


def shuffle_and_pick(items, n=5):
    if items is None or len(items) == 0:
        return []

    random.shuffle(items)
    return items[:n]
